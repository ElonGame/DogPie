import bpy
from math import radians, degrees
from bpy.props import IntProperty, FloatProperty
from bpy_extras import view3d_utils

class TogglePie(bpy.types.Menu):
    bl_idname = "dog.toggle_pie"
    bl_label = "Toggle Pie"

    @classmethod
    def poll(self, context):
        return True
    
    def draw(self, context):
        layout = self.layout
        
        p = layout.menu_pie()
        #left
        #b = p.box()
        p.operator(ToggleDisplayWireOperator.bl_idname, icon = 'SHADING_WIRE')     
               
        #right
        #b = p.box()
        p.operator(ToggleViewCameraOperator.bl_idname, icon = 'VIEW_CAMERA')
        
        #down
        #b = p.box()
        p.operator(ToggleOverlayOperator.bl_idname, icon = 'OVERLAY')

        #up
        #b = p.box()
        p.operator(ToggleRenderEngineOperator.bl_idname, icon = 'SHADING_RENDERED') 
               
        #upper left
        #b = p.box()
        p.operator(ToggleAutoSmoothOperator.bl_idname, icon = 'MESH_CIRCLE') 
        
        #upper right
        p.operator(ToggleSelectableOperator.bl_idname, icon = 'RESTRICT_SELECT_ON')   

        #lower left
        #b = p.box()

        p.operator(ToggleXRayOperator.bl_idname, icon = 'XRAY') 
        
        #lower right
        #b = p.box()
        p.operator(ToggleFaceOrientationOperator.bl_idname, icon = 'ORIENTATION_NORMAL')
        
def ToggleAutoSmooth(context):
    objects = context.selected_objects
    flag = False
    for ob in objects:
        if ob.data.use_auto_smooth == False:
            flag = True
            break

    if flag:
        for ob in objects:
            ob.data.use_auto_smooth = True
            ob.data.auto_smooth_angle = radians(60)
        bpy.ops.object.shade_smooth()
    else:
        for ob in objects:
            ob.data.use_auto_smooth = False
        bpy.ops.object.shade_flat()
        
def ToggleOverlay(context):
    context.space_data.overlay.show_overlays = 1 - context.space_data.overlay.show_overlays

def ToggleRenderEngine(context):
    if context.scene.render.engine == 'CYCLES':
        context.scene.render.engine = 'BLENDER_EEVEE'
    elif context.scene.render.engine == 'BLENDER_EEVEE':
        context.scene.render.engine = 'CYCLES'
    
def ToggleFaceOrientation(context):
    bpy.context.space_data.overlay.show_face_orientation = 1 - bpy.context.space_data.overlay.show_face_orientation
    
def ToggleDisplayWire(context):
    objects = context.selected_objects
    flag = False
    for ob in objects:
        if ob.display_type == 'SOLID':
            flag = True
            break

    if flag:
        # exsist not wire
        for ob in objects:
            ob.display_type = 'WIRE'
    else:
        # all wire
        for ob in objects:
            ob.display_type = 'SOLID'

def ToggleXRay(context):
    context.space_data.shading.show_xray = 1 - context.space_data.shading.show_xray

def ToggleSelectable(context):
    objects = context.selected_objects
    for ob in objects:
        ob.hide_select = 1 - ob.hide_select

class ToggleOverlayOperator(bpy.types.Operator):
    bl_idname = "dog.toggle_overlay"
    bl_label = "Toggle Overlay"
    
    def execute(self, context):
        ToggleOverlay(context)
        return {'FINISHED'}
             
class ToggleXRayOperator(bpy.types.Operator):
    bl_idname = "dog.toggle_xray"
    bl_label = "Toggle XRay"
    
    def execute(self, context):
        ToggleXRay(context)
        return {'FINISHED'}

def ToggleViewCamera(context):
    objects = context.selected_objects
    cameras = []
    flag = True
    for ob in objects:
        if ob.type == 'CAMERA':
            flag = False
            cameras.append(ob)
    
    if flag:
        # Add a camera and align to view
        bpy.ops.object.camera_add(enter_editmode=False, align='VIEW', location=(0, 0, 0), rotation=(1.08771, 0.0131375, 1.12702))

        bpy.ops.view3d.object_as_camera()
        bpy.ops.view3d.view_camera()
        bpy.ops.view3d.camera_to_view()
    else:
        # delete camera
        bpy.ops.object.delete({"selected_objects": cameras})
        
def main(context, event, ray_origin, view_vector):
    """Run this function on left mouse, execute the ray cast"""
    
    ray_target = ray_origin + view_vector

    def visible_objects_and_duplis():
        """Loop over (object, matrix) pairs (mesh only)"""

        depsgraph = context.evaluated_depsgraph_get()
        for dup in depsgraph.object_instances:
            if dup.is_instance:  # Real dupli instance
                obj = dup.instance_object
                yield (obj, dup.matrix_world.copy())
            else:  # Usual object
                obj = dup.object
                yield (obj, obj.matrix_world.copy())

    def obj_ray_cast(obj, matrix):
        """Wrapper for ray casting that moves the ray into object space"""


        # get the ray relative to the object
        matrix_inv = matrix.inverted()
        ray_origin_obj = matrix_inv @ ray_origin
        ray_target_obj = matrix_inv @ ray_target
        ray_direction_obj = ray_target_obj - ray_origin_obj

        # cast the ray
        success, location, normal, face_index = obj.ray_cast(ray_origin_obj, ray_direction_obj)

        if success:
            return location, normal, face_index
        else:
            return None, None, None

    # cast rays and find the closest object
    best_length_squared = -1.0
    best_obj = None
    best_hit_world = None
    best_hit_normal = None

    for obj, matrix in visible_objects_and_duplis():
        if obj.type == 'MESH':
            hit, normal, face_index = obj_ray_cast(obj, matrix)
            if hit is not None:
                hit_world = matrix @ hit
                length_squared = (hit_world - ray_origin).length_squared
                if best_obj is None or length_squared < best_length_squared:
                    best_length_squared = length_squared
                    best_obj = obj
                    best_hit_world = hit_world
                    best_hit_normal = matrix @ normal

    # now we have the object under the mouse cursor,
    # we could do lots of stuff but for the example just select.
    if best_obj is not None:
        light_pos = best_hit_world + best_hit_normal
        bpy.ops.object.light_add(type='POINT', radius=1, location=light_pos)
    else:
        light_pos = ray_origin + view_vector * 20
        bpy.ops.object.light_add(type='POINT', radius=1, location=light_pos)

class ToggleLightOperator(bpy.types.Operator):
    bl_idname = "dog.toggle_light_operator"
    bl_label = "Toggle Light"
    
    first_mouse_x : IntProperty()
    lights = {}
    Delta : FloatProperty()
    
    ray_origin = None
    view_vector = None
    
    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            delta = event.mouse_x - event.mouse_prev_x
            print(event.mouse_x)
            for ob in self.lights:
                ob.data.energy += delta
                if ob.data.energy < 0:
                    ob.data.energy = 0
            
            self.Delta += delta
            # draw some text
            context.area.header_text_set("Delta : %.f" % self.Delta)
            
            if event.mouse_x < 1:
                context.window.cursor_warp(context.region.width, event.mouse_y)
            if event.mouse_x > context.region.width - 1:
                context.window.cursor_warp(0, event.mouse_y)

        elif event.type == 'LEFTMOUSE':
            context.area.header_text_set(None)
            return {'FINISHED'}
        
        elif event.type == 'RIGHTMOUSE':
            context.area.header_text_set(None)
            for ob, energy in self.lights.items():
                ob.data.energy = energy
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}
        
    def invoke(self, context, event):
        # clear dict
        self.lights.clear()
        self.Delta = 0
        # get the context arguments
        scene = context.scene
        region = context.region
        rv3d = context.region_data
        coord = event.mouse_region_x, event.mouse_region_y

        # get the ray from the viewport and mouse
        self.view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        self.ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        
        
        objects = context.selected_objects
        self.first_mouse_x = event.mouse_x
        flag = False  
        for ob in objects:
            if ob.type == 'LIGHT':
                flag = True
                self.lights[ob] = ob.data.energy
        # if light exsist
        if flag:
            # toggle light energy
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            # Create a light at cursor with 1 unit offset along surface normal
            main(context, event, self.ray_origin, self.view_vector)
            return {'FINISHED'}

    
class ToggleAutoSmoothOperator(bpy.types.Operator):
    bl_idname = "dog.toggle_auto_smooth"
    bl_label = "Toggle Auto Smooth"
    
    first_mouse_x : IntProperty()
    meshes = {}
    Delta : FloatProperty()
    
    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            delta = event.mouse_x - event.mouse_prev_x
            delta = delta * 0.3
            if event.shift == True:
                delta = delta * 0.1
            for ob in self.meshes:
                ob.data.auto_smooth_angle += radians(delta)
                
            self.Delta += delta
            # draw some text
            context.area.header_text_set("Delta : %.1f" % self.Delta)
            
            if event.mouse_x < 1:
                context.window.cursor_warp(context.region.width, event.mouse_y)
            if event.mouse_x > context.region.width - 1:
                context.window.cursor_warp(0, event.mouse_y)
            
        elif event.type == 'LEFTMOUSE':
            context.area.header_text_set(None)
            return {'FINISHED'}
        
        elif event.type == 'RIGHTMOUSE':
            context.area.header_text_set(None)
            for ob, angle in self.meshes.items():
                ob.data.auto_smooth_angle = angle
            return {'CANCELLED'}
        
        return {'RUNNING_MODAL'}
        
    def invoke(self, context, event):
        # clear dict
        self.meshes.clear()
        self.Delta = 0
        
        objects = context.selected_objects
        self.first_mouse_x = event.mouse_x
        flag = False  
        for ob in objects:
            if ob.type == 'MESH':
                self.meshes[ob] = degrees(ob.data.auto_smooth_angle)
                if ob.data.use_auto_smooth == False:
                    flag = True

        # if exsist sth not auto smooth
        if flag:
            # turn on auto smooth and use smooth shading
            for ob in self.meshes:
                ob.data.use_auto_smooth = True
            bpy.ops.object.shade_smooth()

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            # turn off auto smooth and use flat shading
            for ob in self.meshes:
                ob.data.use_auto_smooth = False
                print(ob.name)
            bpy.ops.object.shade_flat()            
            return {'FINISHED'}

    
class ToggleRenderEngineOperator(bpy.types.Operator):
    bl_idname = "dog.toggle_render_engine"
    bl_label = "Toggle Render Engine"
    
    def execute(self, context):
        ToggleRenderEngine(context)
        return {'FINISHED'}
    
class ToggleDisplayWireOperator(bpy.types.Operator):
    bl_idname = "dog.toggle_display_wire"
    bl_label = "Toggle Display Wire"
    
    def execute(self, context):
        ToggleDisplayWire(context)
        return {'FINISHED'}
    
class ToggleSelectableOperator(bpy.types.Operator):
    bl_idname = "dog.toggle_selectable"
    bl_label = "Toggle Selectable"
    
    def execute(self, context):
        ToggleSelectable(context)
        return {'FINISHED'}
    
class ToggleFaceOrientationOperator(bpy.types.Operator):
    bl_idname = "dog.toggle_face_orientation"
    bl_label = "Toggle Face Orientation"
    
    def execute(self, context):
        ToggleFaceOrientation(context)
        return {'FINISHED'}
    
class ToggleViewCameraOperator(bpy.types.Operator):
    bl_idname = "dog.toggle_view_camera"
    bl_label = "View Camera"
    
    def execute(self, context):
        ToggleViewCamera(context)
        return {'FINISHED'}
   
classes = [
    TogglePie,
    ToggleOverlayOperator,
    ToggleLightOperator,
    ToggleAutoSmoothOperator,
    ToggleRenderEngineOperator,
    ToggleDisplayWireOperator,
    ToggleSelectableOperator,
    ToggleFaceOrientationOperator,
    ToggleViewCameraOperator,
    ToggleXRayOperator
]

ka = bpy.context.window_manager.keyconfigs.addon
key = []

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
        
    km = ka.keymaps.new(name = '3D View', space_type = 'VIEW_3D', region_type = 'WINDOW')
    kmi = km.keymap_items.new('wm.call_menu_pie', type = 'BUTTON4MOUSE', value = 'PRESS')
    kmi.properties.name = TogglePie.bl_idname
    key.append((km,kmi))
    
    kmi = km.keymap_items.new(ToggleLightOperator.bl_idname, type = 'LEFTMOUSE', value = 'PRESS', key_modifier = 'L')
    key.append((km,kmi))
        
def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
        
    ka = bpy.context.window_manager.keyconfigs.addon
    if ka:
        for km,kmi in key:
            km.keymap_items.remove(kmi)
    key.clear()


if __name__ == "__main__":
    register()
    
