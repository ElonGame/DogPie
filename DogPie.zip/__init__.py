
bl_info = {
    "name" : "DogPie",
    "author" : "Dog012",
    "description" : "Pie Menu for some built-in function",
    "blender" : (2, 80, 0),
    "version" : (0, 1, 2),
    "location" : "3d视图下按鼠标侧键：切换饼菜单, L + 鼠标左键：快捷灯光",
    "category" : "Generic"
}

from . import SwitchEditorMenu, ToggleMenu

def register():
	SwitchEditorMenu.register()
	ToggleMenu.register()
	
def unregister():
	ToggleMenu.unregister()
	SwitchEditorMenu.unregister()