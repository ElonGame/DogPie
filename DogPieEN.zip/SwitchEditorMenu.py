import bpy

class SwitchEditorPie(bpy.types.Menu):
    bl_idname = "dog.switch_editor_menu"
    bl_label = "Switch Editor Menu"
    
    def draw(self, context):
        layout = self.layout
        
        p = layout.menu_pie()
        #left
        #b = p.box()
        p.operator(SwitchEditorOperator0.bl_idname, icon = 'VIEW3D')        
        #right
        #b = p.box()
        p.operator(SwitchEditorOperator1.bl_idname, icon = 'NODE_MATERIAL')        
        #down
        #b = p.box()
        p.operator(SwitchEditorOperator5.bl_idname, icon = 'PROPERTIES')
        #up
        #b = p.box()
        p.operator(SwitchEditorOperator6.bl_idname, icon = 'OUTLINER')        
        #upper left
        #b = p.box()
        p.operator(SwitchEditorOperator2.bl_idname, icon = 'UV')
        #upper right
        #b = p.box()
        p.operator(SwitchEditorOperator4.bl_idname, icon = 'NODE_COMPOSITING')
        #lower left
        #b = p.box()
        p.operator(SwitchEditorOperator3.bl_idname, icon = 'IMAGE')
        #lower right
        #b = p.box()
        p.operator(SwitchEditorOperator7.bl_idname, icon = 'NODE_TEXTURE')



        
class SwitchEditorOperator0(bpy.types.Operator):
    bl_idname = "dog.switch_editor_ops0"
    bl_label = "3D View"
    
    def execute(self, context):
        SwitchEditor(context, "VIEW_3D")
        return {'FINISHED'}
    
class SwitchEditorOperator1(bpy.types.Operator):
    bl_idname = "dog.switch_editor_ops1"
    bl_label = "Material"
    
    def execute(self, context):
        SwitchEditor(context, "ShaderNodeTree")
        return {'FINISHED'}
    
class SwitchEditorOperator2(bpy.types.Operator):
    bl_idname = "dog.switch_editor_ops2"
    bl_label = "UV"
    
    def execute(self, context):
        SwitchEditor(context, "UV")
        return {'FINISHED'}
    
class SwitchEditorOperator3(bpy.types.Operator):
    bl_idname = "dog.switch_editor_ops3"
    bl_label = "Image"
    
    def execute(self, context):
        SwitchEditor(context, "VIEW")
        return {'FINISHED'}
    
class SwitchEditorOperator4(bpy.types.Operator):
    bl_idname = "dog.switch_editor_ops4"
    bl_label = "Compositor"
    
    def execute(self, context):
        SwitchEditor(context, "CompositorNodeTree")
        return {'FINISHED'}
    
class SwitchEditorOperator5(bpy.types.Operator):
    bl_idname = "dog.switch_editor_ops5"
    bl_label = "Properties"
    
    def execute(self, context):
        SwitchEditor(context, "PROPERTIES")
        return {'FINISHED'}
    
class SwitchEditorOperator6(bpy.types.Operator):
    bl_idname = "dog.switch_editor_ops6"
    bl_label = "Outliner"
    
    def execute(self, context):
        SwitchEditor(context, "OUTLINER")
        return {'FINISHED'}
    
class SwitchEditorOperator7(bpy.types.Operator):
    bl_idname = "dog.switch_editor_ops7"
    bl_label = "Texture Node"
    
    def execute(self, context):
        SwitchEditor(context, "TextureNodeTree")
        return {'FINISHED'}

    
def SwitchEditor(context, name):
    context.area.ui_type = name
        
classes = [
    SwitchEditorPie,
    SwitchEditorOperator0,
    SwitchEditorOperator1,
    SwitchEditorOperator2,
    SwitchEditorOperator3,
    SwitchEditorOperator4,
    SwitchEditorOperator5,
    SwitchEditorOperator6,
    SwitchEditorOperator7,
]        

ka = bpy.context.window_manager.keyconfigs.addon
key = []

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
        
    km = ka.keymaps.new(name = 'Window', space_type = 'EMPTY', region_type = 'WINDOW')
    kmi = km.keymap_items.new('wm.call_menu_pie', type = 'BUTTON5MOUSE', value = 'PRESS')
    kmi.properties.name = SwitchEditorPie.bl_idname
    
    key.append((km,kmi))
    
def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
        
    ka = bpy.context.window_manager.keyconfigs.addon
    if ka:
        for km,kmi in key:
            km.keymap_items.remove(kmi)
    key.clear()


if __name__ == "__main__":
    register()
    
