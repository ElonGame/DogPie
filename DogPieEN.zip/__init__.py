
bl_info = {
    "name" : "DogPie",
    "author" : "Dog012",
    "description" : "Pie Menu for some built-in function",
    "blender" : (2, 80, 0),
    "version" : (0, 1, 2),
    "location" : "press mouse3 and mouse4 in 3d view for toggle pie, press left mouse button with L for a quick light",
    "category" : "Generic"
}

from . import SwitchEditorMenu, ToggleMenu

def register():
	SwitchEditorMenu.register()
	ToggleMenu.register()
	
def unregister():
	ToggleMenu.unregister()
	SwitchEditorMenu.unregister()